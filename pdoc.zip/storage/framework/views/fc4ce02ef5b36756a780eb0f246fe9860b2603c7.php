<?php $__env->startSection('title'); ?>
    PDOC - Employee Hours
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <h1 class="mt-4"></h1>
        <ol class="breadcrumb mb-4">
            <li class="breadcrumb-item"><a href="index.html">Dashboard</a></li>
            <li class="breadcrumb-item active">Hours</li>
            <li class="breadcrumb-item active">View Employee Hours History</li>
        </ol>
        <div class="card mb-4">
            
            <div class="card-body">
                <form method="POST" action="<?php echo e(route('view_employee_hours', ['id' => $employee_id])); ?>">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" value="<?php echo e($employee_id); ?>" name="employee_id">

                    <div class="form-row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="small mb-1 required" for="from_date">From Date</label>
                                <input class="form-control py-4 <?php $__errorArgs = ['from_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="from_date" type="date" name="from_date" value="<?php echo e($from_date?$from_date:''); ?>" required/>

                                <?php $__errorArgs = ['from_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="small mb-1 required" for="to_date">To Date</label>
                                <input class="form-control py-4 <?php $__errorArgs = ['to_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="to_date" type="date" name="to_date" value="<?php echo e($to_date?$to_date:''); ?>" required/>

                                <?php $__errorArgs = ['to_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>

                    <div class="form-group mt-4 mb-0">
                        <button type="submit" class="btn btn-primary btn-block">
                            View Hours History
                        </button>
                        
                    </div>
                </form>

                <hr>

                <?php if($hours_history != null): ?>
                    <table class="table">
                        <?php $total_hours = 0; $total_stat_hours=0; $total_overtime_hours=0; ?>
                        <?php $__currentLoopData = $hours_history; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $history): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <thead class="thead-light">
                            <tr>
                                <th scope="col">
                                    Day: <?php echo e($history->work_date->format('l')); ?>

                                    <?php if($history->is_state_holiday): ?>
                                        <span class="badge px-2 py-1 <?php echo e($history->is_state_holiday? 'badge-success' : ''); ?> badge-pill">
                                        Stat Holiday
                                    </span>
                                    <?php endif; ?>
                                    <?php if($history->is_over_time): ?>
                                        <span class="badge px-2 py-1 <?php echo e($history->is_over_time? 'badge-success' : ''); ?> badge-pill">
                                        Over Time
                                    </span>
                                    <?php endif; ?>

                                </th>
                                <th scope="col">Date: <?php echo e($history->work_date->format('Y-m-d')); ?></th>
                            </tr>
                            </thead>
                            <tbody>
                            <tr>
                                <td>
                                    Hours: <?php echo e($history->work_hours); ?>

                                    sta <?php echo e($history->is_state_holiday); ?>

                                    ot: <?php echo e($history->is_over_time); ?>

                                    <?php
                                        if ($history->is_state_holiday == 1){
                                            $total_stat_hours += $history->work_hours;
                                        }elseif ($history->is_over_time == 1){
                                            $total_overtime_hours += $history->work_hours;
                                        }else {
                                            $total_hours += $history->work_hours;
                                        }
                                    ?>

                                    <br>
                                    OverTime Hours: <?php echo e($history->over_time_hours? $history->over_time_hours : '0.0'); ?>

                                </td>
                                <td></td>
                            </tr>
                            </tbody>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                    <hr>
                    <div class="bg-success text-white px-2 py-2">
                        <div class="row">
                            <div class="col-sm">Total Hours: <?php echo e($total_hours); ?></div>
                            <div class="col-sm">Stat Holiday Hours: <?php echo e($total_stat_hours); ?></div>
                            <div class="col-sm">OverTime Hours: <?php echo e($total_overtime_hours); ?></div>
                        </div>

                        <?php
                            function convertTime($dec){
                                // start by converting to seconds
                                $seconds = ($dec * 3600);
                                // we're given hours, so let's get those the easy way
                                $hours = floor($dec);
                                // since we've "calculated" hours, let's remove them from the seconds variable
                                $seconds -= $hours * 3600;
                                // calculate minutes left
                                $minutes = floor($seconds / 60);
                                // remove those from seconds as well
                                $seconds -= $minutes * 60;
                                // return the time formatted HH:MM:SS
                                //return lz($hours).":".lz($minutes).":".lz($seconds);
                                return lz($hours).":".lz($minutes);
                            }

                            // lz = leading zero
                            function lz($num){return (strlen($num) < 2) ? "0{$num}" : $num;}

                        echo '<div class="row">';
                        echo '<div class="col-sm">Total Hours: '. convertTime($total_hours). '</div><div class="col-sm">' .'Stat Holiday Hours: '.convertTime($total_stat_hours). '</div><div class="col-sm">OverTime Hours: '.convertTime($total_overtime_hours). '</div>';
                        echo '</div></div>';
                        ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('after_load'); ?>
    <?php if(Session::get('msg')): ?>
        <script type="text/javascript">
            showSuccess("<?php echo e(Session::get('msg')); ?>");
        </script>
    <?php else: ?>
        <!--<script type="text/javascript">
                console.log('no msg');
                showSuccess('no msg');
            </script>-->
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pdoc\resources\views\dashboard\hours\history.blade.php ENDPATH**/ ?>