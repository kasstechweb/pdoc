<?php $__env->startSection('title'); ?>
    PDOC - Employee Hours
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
    <link href="<?php echo e(asset('css/jquery.dataTables.css')); ?>" rel="stylesheet">
    <style>
        td.details-control {
            background: url('<?php echo e(asset('img/details_open.png')); ?>') no-repeat center center;
            cursor: pointer;
        }
        tr.shown td.details-control {
            background: url('<?php echo e(asset('img/details_close.png')); ?>') no-repeat center center;
        }
    </style>
    <link rel="stylesheet" type="text/css"
          href="<?php echo e(asset('css/dataTables.bootstrap.css')); ?>"/>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <h1 class="mt-4"></h1>
        <ol class="breadcrumb mb-4">
            <li class="breadcrumb-item"><a href="index.html">Dashboard</a></li>
            <li class="breadcrumb-item active">Hours</li>
            <li class="breadcrumb-item active">
            <?php if($action == 'add_hours'): ?>
                Add Hours
            <?php elseif($action == 'view_hours_history'): ?>
                Hours History
            <?php elseif($action == 'view_all'): ?>
                    View All Employees
            <?php endif; ?>

            </li>
        </ol>
        <div class="card mb-4">
            
            <div class="card-body table-responsive">
                <table id="example" class="display nowrap " cellspacing="0" width="100%">
                    <thead>
                    <tr>
                        <th></th>
                        <th>#</th>
                        <th>name</th>


                        <th>SIN #</th>
                        <th></th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr data-child-value="
                            Address: <?php echo e($employee->address); ?> <br>
                            Hire Date: <?php echo e($employee->hire_date); ?> <br>
                            Termination Date: <?php echo e($employee->termination_date); ?>">
                            <td class="details-control"></td>
                            <td><?php echo e($employee->id); ?></td>
                            <td><?php echo e($employee->name); ?></td>


                            <td><?php echo e($employee->sin); ?></td>
                            <td class="m-auto">
                                <?php if($action == 'add_hours'): ?>
                                    <a class="btn btn-success" href="<?php echo e(route('add_employee_hours', ['id' => $employee->id])); ?>">
                                        <i class="fas fa-user-clock"></i>
                                        Add Hours
                                    </a>
                                <?php elseif($action == 'view_hours_history'): ?>
                                    <a class="btn btn-success" href="<?php echo e(route('view_employee_hours', ['id' => $employee->id])); ?>">
                                        <i class="fas fa-clock"></i>
                                        View Hours History
                                    </a>
                                <?php elseif($action == 'view_all'): ?>
                                    <a class="btn btn-primary">
                                        <i class="fas fa-pen"></i>
                                        Edit
                                    </a>
                                    <a class="btn btn-danger">
                                        <i class="fas fa-trash-alt"></i>
                                        Delete
                                    </a>
                                <?php endif; ?>

                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('after_load'); ?>
    <script type="text/javascript">
        function format(value) {
            return '<div class="pl-5">' + value + '</div>';
        }
        $(document).ready(function () {
            var table = $('#example').DataTable({});

            // Add event listener for opening and closing details
            $('#example').on('click', 'td.details-control', function () {
                var tr = $(this).closest('tr');
                var row = table.row(tr);

                if (row.child.isShown()) {
                    // This row is already open - close it
                    row.child.hide();
                    tr.removeClass('shown');
                } else {
                    // Open this row
                    row.child(format(tr.data('child-value'))).show();
                    tr.addClass('shown');
                }
            });
        });
    </script>
    <script type="text/javascript" src="<?php echo e(asset('js/dataTables.bootstrap.js')); ?>"></script>
    <?php if(Session::get('msg')): ?>
        <script type="text/javascript">
            showSuccess("<?php echo e(Session::get('msg')); ?>");
        </script>
    <?php else: ?>
        <!--<script type="text/javascript">
            console.log('no msg');
            showSuccess('no msg');
        </script>-->
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pdoc\resources\views\dashboard\all_employees.blade.php ENDPATH**/ ?>